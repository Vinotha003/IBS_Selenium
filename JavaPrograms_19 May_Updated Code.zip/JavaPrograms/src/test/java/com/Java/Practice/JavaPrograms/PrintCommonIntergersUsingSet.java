package com.Java.Practice.JavaPrograms;

import java.util.HashSet;
import java.util.Set;

public class PrintCommonIntergersUsingSet {
	public static void main(String[] args){

		int[] a= {2,5,8,9,0};
		int[] b = {8,6,9,2,0};
		
		Set<Integer> hs=new HashSet<>();
		for(int num:a)
		{
			hs.add(num);
			
		}
		for(int num1:b)
		{
			if(hs.contains(num1))
			{
				System.out.println(num1);
			}
		}
	}

}
