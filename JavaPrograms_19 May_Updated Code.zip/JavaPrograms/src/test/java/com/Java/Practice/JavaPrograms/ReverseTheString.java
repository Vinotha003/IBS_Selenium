package com.Java.Practice.JavaPrograms;

public class ReverseTheString {
	public static void main(String args[])
	{
	String str="All that glitters are not gold";
	StringBuilder sb=new StringBuilder();
	String [] s=str.split(" ");
	
	for(int i=s.length-1;i>=0;i--)
	{
		//String word=s[i];
		sb.append(s[i]).toString();
		sb.append(" ");
	}
	
	System.out.println(sb);
}
}