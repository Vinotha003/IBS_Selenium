package com.Java.Practice.JavaPrograms;

public class ReverseEachWordAndString {
	
	
	    public static void main(String[] args) {
	       
	        String s ="Vinotha is a good automation tester";
	        StringBuffer sb1= new StringBuffer();
	        StringBuffer sb2= new StringBuffer();
	        String [] str= s.split(" ");
	        for(int i=str.length-1;i>=0;i--)
	        {
	            sb1.append(new StringBuffer(str[i]).toString());
	            sb1.append(" ");
	            sb2.append(new StringBuffer(str[i]).reverse().toString());
	            sb2.append(" ");
	            
	        }
	        System.out.println("Reverse the given string: " + sb1);
	         System.out.println("Reverse each word and string: " + sb2);
	    }
	}


