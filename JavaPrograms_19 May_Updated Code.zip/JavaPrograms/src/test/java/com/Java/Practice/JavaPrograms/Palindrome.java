package com.Java.Practice.JavaPrograms;
import java.util.Scanner;

public class Palindrome {

	public static void isPalindrome(String s) {
		String org=s;

		String rev="";

		for(int i=s.length()-1;i>=0;i--) {		
			//rev=rev+s.charAt(i);
			rev += s.charAt(i);
		}	
		System.out.println(rev);

		if(org.equals(rev)) {
			System.out.println(org+" string is a palindrome");
		}else
			System.out.println(org+" string is not a palindrome");
	}
	
	public static void reverseNum1() {
		//Scanner s=new Scanner(System.in);
		//System.out.println("Enter the number: ");
		//int a = s.nextInt();
		int a =102;
		int n=a;
	int rev=0;
		while(n!=0) {
			rev=rev*10+n%10;
			n=n/10;
		}
		System.out.println(rev);
		if (a==rev)
			
			System.out.println(rev+" num is a palindrome");
		
		else
			System.out.println(rev+" num is not a palindrome");
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="madam";
		Palindrome p =new Palindrome();
		p.isPalindrome(s);
		p.reverseNum1();
		
	}

}
