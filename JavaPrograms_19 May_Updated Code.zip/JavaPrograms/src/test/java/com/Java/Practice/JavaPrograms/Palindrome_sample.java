package com.Java.Practice.JavaPrograms;

public class Palindrome_sample {
	// Online Java Compiler
	// Use this editor to write, compile and run your Java code online

	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String str="Madam";
	        str= str.toLowerCase();
	        String rev= "";
	        for(int i=str.length()-1;i>=0;i--){
	        rev += str.charAt(i);
	    }
	    if(str.equals(rev)){
	      System.out.println(rev +" " +str +" " +"Palindrome"); 
	    }
	      else {
	     System.out.println(rev +" " +str +" " +" Not not Palindrome"); 
	    } 
	    }
	}


