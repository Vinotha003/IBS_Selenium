package com.Java.Practice.JavaPrograms;

public class ReverseLastWord {
	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String str="Welcome to Capgemini";
	        StringBuilder sb= new StringBuilder();
	        String s[]= str.split(" ");
	        String lastword=s[s.length-1];
	        String revlast=new StringBuilder(lastword).reverse().toString();
	        s[s.length-1]= revlast;
	        for(String word:s)
	        {
	            sb.append(word);
	            sb.append(" ");
	        }
	        System.out.println(sb);
	    }
	}



