package com.Java.Practice.JavaPrograms;

public class ReverseLongestWord2 {
	public static void main(String args[])
	{
	String str="All that glitters are not gold";
	StringBuilder sb=new StringBuilder();
	String [] s=str.split(" ");
	int maxlength=0;
	int longestindex= -1;
	for(int i=0;i<s.length;i++)
	{
		if(s[i].length()>maxlength)
		{
			maxlength=	s[i].length();
			longestindex=i;
			
		}
	}
	String rev= new StringBuilder(s[longestindex]).reverse().toString();
	s[longestindex]=rev;
	for(String word:s)
    {
        sb.append(word);
        sb.append(" ");
    }
	System.out.println(sb);
	

}
}

