package com.Java.Practice.JavaPrograms;

public class ReplaceRepeatedCharByNum {// Online Java Compiler
	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s="aabbbgq";
	        StringBuilder sb=new StringBuilder();
	        for(int i =0;i<s.length();i++)
	        {
	          char ch=s.charAt(i);
	          int count=1;
	          while(i+1<s.length()&&s.charAt(i+1)==ch)
	          {
	              count++;
	              i++;
	          }
	          sb.append(ch).append(count);
	        }
	         System.out.println(sb);
	    }
	}


