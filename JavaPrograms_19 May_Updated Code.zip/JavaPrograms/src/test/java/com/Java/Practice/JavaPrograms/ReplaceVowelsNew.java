package com.Java.Practice.JavaPrograms;

public class ReplaceVowelsNew {
	public static  void practic1() {
		StringBuilder output = new StringBuilder();
		String str = "Welcome to Barclays";

		String[] word1 = str.split(" ");
		for (String s:word1)
		{
			if (s.length()>2)
			{
				output.append(s.charAt(0));
				String reverse =new StringBuilder(s.substring(1)).reverse().append(" ").toString();

				output.append(reverse);
			}
			else {
				output.append(s).append(" ");
			}
		}
		System.out.println(output.toString().trim());
	}


	public static  void practic2() {
		String sentence = "Replace vowels with spaces";
		char[] sentenceArray = sentence.toCharArray(); // Convert to char array
		String result = "";

		for (char ch : sentenceArray) {
			// Check if the character is a vowel (lowercase or uppercase)
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
					ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
				result += " "; // Replace with space
			} else {
				result += ch; // Keep the original character
			}
		}

		System.out.println("Modified sentence: " + result);
	}

	public static  void practic3() {
		StringBuilder output = new StringBuilder();
		String str = "Replace vowels with spaces";

		//String[] word1 = str.split(" ");
		for (int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			if (ch=='a'||ch=='e' || ch == 'i' || ch == 'o' || ch == 'u')
			{

				output.append(" ");
			}
			else {
				output.append(ch);
			}
		}
		System.out.println("Modified sentence: "+output);
	}


	public static  void practic4() {
		String s = "Replace vowels with spaces";
		System.out.println("original string: "+s);
		//s=s.replaceAll("[aeiouAEIOU]", " ");
		s=s.replaceAll("[aeiouAEIOU]", "*");
		System.out.println("Replaced string: "+s);

	}
	public static  void practic5() {
		StringBuilder output = new StringBuilder();
		String str = "vinotha";
		int count =0;

		//String[] word1 = str.split(" ");
		for (int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			if (ch=='a'||ch=='e' || ch == 'i' || ch == 'o' || ch == 'u')
			{
			
				count++;
				for(int j=1;j<=count;j++) {
				output.append("*");
			}
			}
			else {
				output.append(ch);
			}
		}
		System.out.println("Modified sentence: "+output);
	}
	public static  void practic6() {
		System.out.println("Try programiz.pro");
        String s="vinotha";
        String res=" ";
        //char c=s.toCharArray();
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')
            {
                res +=" ";
                
            }
            else
            {
                res +=s.charAt(i);
            }
        }
        System.out.println(res);
	}
	public static void main(String[] args){
		practic5();
		practic6();
		//practic3(); 
		//practic2();


	}
}

