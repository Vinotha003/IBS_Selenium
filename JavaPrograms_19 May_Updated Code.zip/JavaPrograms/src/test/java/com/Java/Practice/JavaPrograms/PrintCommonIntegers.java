package com.Java.Practice.JavaPrograms;

public class PrintCommonIntegers {
	public static void main(String[] args){

		int[] a= {2,5,8,9,0,6};
		int[] b = {1,7,9,2,0};
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				if(a[i]==b[j]) {
					
					System.out.println(a[i]);
				}
			}
		}
		
	}
}
