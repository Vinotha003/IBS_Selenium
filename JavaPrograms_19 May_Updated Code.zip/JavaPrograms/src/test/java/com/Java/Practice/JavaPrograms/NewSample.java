package com.Java.Practice.JavaPrograms;

public class NewSample {
	 public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s="Vinotha is a good automation tester";
	        StringBuilder sb = new StringBuilder();
	        int max =0;
	        int index=-1;
	        String [] str=s.split(" ");
	        for(int i=0;i< str.length;i++)
	        {
	            if (str[i].length()>max){
	            max= str[i].length();
	            index=i;
	            }      
	    }
	       String rev =new StringBuilder(str[index]).reverse().toString();
	      str[index]=rev;
	      System.out.println( str[index]); 
	      for(String word:str)
	      {
	          sb.append(word).append(" ");
	      }
	        
	     System.out.println(sb);   
	    }

}
