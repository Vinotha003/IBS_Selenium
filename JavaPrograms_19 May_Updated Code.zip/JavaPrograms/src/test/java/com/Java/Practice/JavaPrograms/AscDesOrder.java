package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class AscDesOrder {
	
    // Function to sort array in ascending order
    public static void sortAscending(int[] arr) {
        for (int i = 0; i < arr.length ; i++) {
            for (int j =i+1; j < arr.length; j++) {
                if (arr[i] > arr[j]) {
                    // Swap arr[i] and arr[j]
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        //if u want convert array to string then use Arrays.toString(arr)
        //System.out.println(Arrays.toString(arr));
        System.out.println("Ascending Order: ");
     // Function to print the array
        for(int i =0;i<arr.length;i++)
       {
        	System.out.println(arr[i]);
        }
       
    }
 
    // Function to sort array in descending order
    public static void sortDescending(int[] arr) {
        for (int i = 0; i < arr.length ; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] < arr[j]) {
                    // Swap arr[i] and arr[j]
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        System.out.println("Descending Order: ");
     // Function to print the array
        for(int i =0;i<arr.length;i++)
        {
        	System.out.println(arr[i]);
        }
    }
 
   /* // Function to print the array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }*/
    public static void main(String[] args) {
        int[] arr = {0,5, 3, 8, 6, 100,0, 200, 4, 1};
 
        // Sorting in ascending order
        sortAscending(arr);
        //System.out.print("Ascending Order: ");
      // printArray(arr);
 
        // Sorting in descending order
        sortDescending(arr);
        //System.out.print("Descending Order: ");
       //printArray(arr);
    }
}
