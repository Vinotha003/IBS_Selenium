package com.Java.Practice.JavaPrograms;

public class CapsFirstLetterInWord {
	public static void main(String args[])
	{
		String s="wELCOME baCK to cognizant";
		StringBuilder sb = new StringBuilder();
		String[] str=s.split(" ");
		for(String word:str)
		{
			// make first letter to caps and reverse the remaining letter and append it 
			sb.append(Character.toUpperCase(word.charAt(0)));
			 //sb.append(word.substring(0,1).toUpperCase());
			
			//Make remaining letter to small except 1st letter
			sb.append(word.substring(1).toLowerCase());
			//sb.append(word.substring(0,word.length()-1).toLowerCase());
			//sb.append(Character.toUpperCase(word.charAt(word.length()-1)));
			//sb.append(new StringBuilder(word.substring(1)).reverse().toString());
			// make first letter to caps and append to remaining letter
			//sb.append(word.substring(1));
			sb.append(" ");
			//sb.append(new StringBuilder(word.substring(1)).reverse().toString().toUpperCase());
			
			
		}
	System.out.println(sb);
	}
	
	

}
