package com.Java.Practice.JavaPrograms;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class example2 {
	public static void hashmap(String str)
	{
		Map<Character,Integer> hm = new HashMap<>();
		char[] ch= str.toCharArray();
		for(Character c : ch)
		{
		if(hm.containsKey(c))
		{
			hm.put(c, hm.get(c)+1);
			
		}
		else
		{
			hm.put(c, 1);
		}
		}
		for(Entry<Character, Integer> e : hm.entrySet())
		{
			//if(e.getValue()>1)
			System.out.println(e.getKey() +":" + e.getValue());
			
		}
		
		
	}
	public static void main(String[] args) {
		String str = "Sugeertha";
		hashmap(str);

}
}
