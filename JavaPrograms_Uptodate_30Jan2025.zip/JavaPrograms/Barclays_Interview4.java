package com.Java.Practice.JavaPrograms;

public class Barclays_Interview4 {
    public static void main(String[] args) {
        String sentence = "Hello World from ChatGPT";
       // String reversedSentence = reverseWords(sentence);
        //System.out.println(reversedSentence); // Output: "ChatGPT from World Hello"
    

   
        // Split the sentence into words using space as the delimiter
        String[] words = sentence.split(" ");
        
        // StringBuilder to build the reversed sentence
        StringBuilder reversed = new StringBuilder();
        
        // Loop through the words in reverse order
        for (int i = words.length - 1; i >= 0; i--) {
            reversed.append(new StringBuilder(words[i]).reverse().toString()).append(" ");
            /*if (i != 0) {
                reversed.append(" "); // Add space between words
            } */
    }
        System.out.println(reversed.toString());
       
}
}





