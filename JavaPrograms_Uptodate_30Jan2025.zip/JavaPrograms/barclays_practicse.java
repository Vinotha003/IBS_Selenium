package com.Java.Practice.JavaPrograms;

public class barclays_practicse {
	
	public static void eachword()
	{
		String str = "vinotha to arvind";
		
		String[] s=str.split(" ");
				StringBuilder sb = new StringBuilder();
				for(String word : s)
				{
					sb.append(new StringBuilder(word).reverse().toString()).append(" ");
					
				}
		System.out.println(sb.toString().trim());
		
	}
	public static void reverseword() {
		String str = "Vinotha to arvind";
		String[] s= str.split(" ");
		StringBuilder sb = new StringBuilder();
		for(String word: s) {
			if(word.length()>2)
					 {
				
				sb.append(word.charAt(0));
				sb.append(word.charAt(1));
				sb.append(new StringBuilder(word.substring(2)).reverse().toString()).append(" ");
				}
			else {
				
				sb.append(word).append(" ");
				
			}
		}
		System.out.println(sb.toString().trim());
	}
	public static void main(String args[]) {
		eachword();
		reverseword();
	}
	
}
