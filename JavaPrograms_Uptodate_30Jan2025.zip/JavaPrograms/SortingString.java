package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class SortingString {
	

	public void SortStringAlphabetically () {
		String input = "example";
        
        // Convert string to a char array
        char[] chars = input.toCharArray();
        
        // Sort the char array
        Arrays.sort(chars);
        
        // Convert the sorted char array back to a string
        String sortedString = new String(chars);
        System.out.println("Sorted string: " + sortedString);
        
        System.out.println("Sorted string in array format: " + Arrays.toString(chars));
    }
	    public static void main(String[] args) {
	    	
	    	SortingString ss= new SortingString();
	    	ss.SortStringAlphabetically();
	}


}
