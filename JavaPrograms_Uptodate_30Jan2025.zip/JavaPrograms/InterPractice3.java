package com.Java.Practice.JavaPrograms;

import java.util.Arrays;
import java.util.Collections;

public class InterPractice3 {
	public static void Asc() {
		int a[] = {1,-99,66,4,3,2,0};
		int num = a.length;
		Arrays.sort(a);
		System.out.println("Ascending order" + Arrays.toString(a));
		System.out.println("smallest" + a[0]);
		System.out.println("second smallest" + a[1]);
		System.out.println("Largest" + a[num-1]);
		System.out.println("Second Largest" + a[num-2]);
		
		
	}
	public static void Des() {
		Integer b[] = {1,-99,66,4,3,2,0};
		Arrays.sort(b, Collections.reverseOrder());
		 
		System.out.println("Descending order" + Arrays.toString(b));
	}
	public static void main(String args[])
	{
		InterPractice3 ip3 = new InterPractice3();
		ip3.Asc();
		
	}
}
