package com.Java.Practice.JavaPrograms;

import java.util.HashSet;
import java.util.TreeSet;

public class RemoveDuplicates {
	public static void remdup()
	{
		
	int[] n= {100,1,30,3,3,3,27,1};
	//HashSet<Integer>hs=new HashSet<>();
	TreeSet<Integer>hs=new TreeSet<>();
	for(int i: n)
	{
		hs.add(i);
	}
	System.out.println(hs);
	
}
	
	public static void main(String[] args) {
		
		RemoveDuplicates rd =new RemoveDuplicates();
		rd.remdup();
		
	}

}
