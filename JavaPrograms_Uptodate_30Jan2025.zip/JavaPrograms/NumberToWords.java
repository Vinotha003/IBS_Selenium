package com.Java.Practice.JavaPrograms;
import java.util.Scanner;

public class NumberToWords {
	
	 
	
	 
	public static void main(String[] args) {
	  // TODO Auto-generated method stub
	Scanner scan = new Scanner(System.in);
	  System.out.println("Enter the number");
	  int number = scan.nextInt();
	  if(number<1|| number>9999) {
	   System.out.println("Invalid Number");
	  }else {
	   int a = number%10; //last digit
	   int b = number/10;
	   int c = b%10;
	   int g = number/100;
	   int d = g%10;
	   int e = number/1000;
	   System.out.println(" a=number%10 : " + a);
	   System.out.println("b=number/10 : " + b);
	   System.out.println("c=b%10 : " + c);
	   System.out.println("g=number/100 : " +g);
	   System.out.println("d=g%10 : " +d);
	   System.out.println("e=number/1000 : " +e);
	   String sD[] = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Ninteen"};
	   String ty[] = {"","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};
	   String h = "Hundred";
	   String th = "Thousand";
	   if(number<20)
	    System.out.println(sD[number]);
	   else if (number>=20 && number<=100)
	    System.out.println(ty[c]+" "+sD[a]);
	   else if(number>=100 && number<=999)
	    System.out.println(sD[g]+" "+h+" "+ty[c]+" "+sD[a]);
	   else
	    System.out.println(sD[e]+" "+th+" "+sD[d]+" "+h+" "+ty[c]+" "+sD[a]);
	    
	  }
	  scan.close();
	}
	 
	

}
