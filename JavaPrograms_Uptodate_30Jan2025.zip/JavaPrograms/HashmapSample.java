package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class HashmapSample {
	public static void Hashmap(String str) {
		 Map<Character, Integer> hm = new HashMap<>();
		 //HashMap<Character,Integer> hm = new HashMap<>();
		 /*hm.put('a', 1);
		 hm.put('b', 1);
		 hm.put('a', 2);
		 System.out.println(hm);*/
		 char ch[]= str.toCharArray();
		 for(char c:ch) {
			 if( hm.containsKey(c)){
				 hm.put(c, hm.get(c)+ 1);
				 }
			 else {
				 hm.put(c, 1);
			 }
			 //System.out.println(hm);
		 }
		 
		/* for (Entry<Character, Integer> e : hm.entrySet()) {
			
			 //if (e.getValue()>1) {
			 
				 System.out.println(e.getKey()+":"+ e.getValue());
		 //}
		 }*/
		 System.out.println(hm);
	}
		 public static void main(String[] args){
			 String str ="Sugeeertha";
			 Hashmap(str);
		    }

}
