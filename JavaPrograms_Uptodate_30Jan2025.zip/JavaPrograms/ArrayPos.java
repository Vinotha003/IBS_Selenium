package com.Java.Practice.JavaPrograms;

public class ArrayPos {
	public static void arrpos(){
		int[] a= {1,4,4,9,9,8,9,6};
		int search = 6;
		int first=-1;
		int last =-1;
		for(int i=0; i<a.length;i++)
		{
			if(a[i]==search && first ==-1) {
				first =i;
				
			}
			else if(a[i]==search && first !=-1)
			{
				last =i;
			}
		}
		System.out.println("First position : " +first);
		System.out.println("Last position : " +last);
	}
	 public static void main(String[] args) {
		 arrpos();
		 
	 }
}
