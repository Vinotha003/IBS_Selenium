package com.Java.Practice.JavaPrograms;

public class SmallestNumOf3 {
	public static void main(String[] args)
	{
		int a=45;
		int b=50;
		int c=60;
		//ternary operator
		int smallest= (c<(a<b?a:b)?c:(a<b?a:b));
				System.out.println(smallest);

}
}
