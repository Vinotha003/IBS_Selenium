package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class SwapFirstAndLastNum {
	public static void main(String[] args){
		int arr[]= {1,3,55,907,2,5,88};
		int temp;
		
			temp =arr[0];
			arr[0]=arr[arr.length-1];
			arr[arr.length-1]=temp;
		System.out.println(Arrays.toString(arr));
		
	}

}
