package com.Java.Practice.JavaPrograms;

public class ReverseAlternateWords {
	public static void ReverseWord() {
		String s="Welcome To London My Love";
		StringBuilder sb =new StringBuilder();
		
		String [] str=s.split(" ");
		for(int i=0;i<str.length;i++) {
			if(i%2!=0)
			{
				sb.append(new StringBuilder(str[i]).reverse().toString());
			}
			else {
				sb.append(str[i]);
			}
			sb.append(" ");
		}
		System.out.println(sb);
	}
	public static void main (String[] args)
	{
		
		ReverseWord();
	}

	

}
