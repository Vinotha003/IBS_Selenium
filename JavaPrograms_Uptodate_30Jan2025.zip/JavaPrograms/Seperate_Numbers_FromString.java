package com.Java.Practice.JavaPrograms;

public class Seperate_Numbers_FromString {
	String str = "SUgeertha0357@#$%^";
	public  void  SeperateLowercase() {
		
		System.out.println("\"The lower case letters are:");
		for (char c : str.toCharArray())
		{
			
			if(Character.isLowerCase(c)){
				System.out.println(c);	
			}
		}
	}
			public  void  Seperatenum() {
				System.out.println("The numbers are:");
				for (char c : str.toCharArray()) {
					
			if(Character.isDigit(c))
			{
				System.out.println(c);
			}
			
			
		}
	}
		public static void main(String[] args) {
			Seperate_Numbers_FromString num = new Seperate_Numbers_FromString();
			num.Seperatenum();
			num.SeperateLowercase();
					
		}
		
	
}
