package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class MoveOddToFront {
	public static void OddToFront()
	{
		int[] a= {2,8,3,5,10,9,6,7};
		int [] temp=new int[a.length];
		int j=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				temp[j]=a[i];
				j++;
			}
		}
		//System.out.println(j);
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				temp[j]=a[i];
				j++;
				
			}
		}
		System.out.println(Arrays.toString(temp));
	//if you want you can copy temp array back to original array that is a[]
		for(int i=0;i<a.length;i++)
		{
			a[i]=temp[i];
			
		}
		System.out.println(Arrays.toString(a));
	}
	public static void main (String[] args)
	{
		
		OddToFront();
	}

}
