package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map.Entry;

public class CountVowelsUsingHashMap {
	public static void vowels(String input) {
       
        // Convert string to lowercase for uniformity
       // input = input.toLowerCase();
 
        // Initialize a HashMap to store vowels and their counts
        HashMap<Character, Integer> vowelCount = new HashMap<>();
 
        // Initialize vowels in the HashMap
       /* for (char vowel : "aeiou".toCharArray()) {
            vowelCount.put(vowel, 0);
        }*/
        vowelCount.put('a', 0);
        vowelCount.put('e', 0);
        vowelCount.put('i', 0);
        vowelCount.put('o', 0);
        vowelCount.put('u', 0);
        // Traverse the string and count vowels
        for (char ch : input.toCharArray()) {
            if (vowelCount.containsKey(ch)) {
                vowelCount.put(ch, vowelCount.get(ch) + 1);
            }
        }
 
        // Print the count of each vowel
        
        /*for (char vowel : vowelCount.keySet()) {
            System.out.println(vowel + ": " + vowelCount.get(vowel));
        }*/
        System.out.println("Vowel counts:");
 for (Entry <Character, Integer>e:vowelCount.entrySet())
 {
	 System.out.println(e.getKey() +": " +e.getValue());
 }
        // Calculate the total number of vowels
       
    }

public static void main(String[] args) {
	//String input = "This is a simple Java program to count vowels";
	String input ="Sugeertha";
	vowels(input);
}
}



	


