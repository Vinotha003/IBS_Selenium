package com.Java.Practice.JavaPrograms;

public class Example1 {
	String s ="HesronVinotha";
	public void rev()
	{
		StringBuffer sb =new StringBuffer(s);
		String v= sb.reverse().toString();
		System.out.println(v);
		
	}
	public static void main(String[] args) {
		Example1 e= new Example1();
		e.rev();
		
	}

}
