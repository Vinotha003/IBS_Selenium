package com.Java.Practice.JavaPrograms;

public class Second_Minimum_Number {
	public static void secondminnum (int arr[])
	{
		//5,78,89,3,2
	int first= Integer.MAX_VALUE;
	int secondmax = Integer.MAX_VALUE;
	for (int i=0; i<arr.length; i++)
	{
	if (arr[i]<first)
	{
		secondmax=first;
		first=arr[i];
		
		
	}
	else if (arr[i]< secondmax && arr[i]!= first )
	{
		secondmax =arr[i];
		
	}
	
	}
	//return secondmax;
	System.out.println("The second smallest num is:" +secondmax);
	}
	 public static void main(String[] args) {
		 int arr[] = {1,-99,4,32,38,2};
		 Second_Minimum_Number min= new Second_Minimum_Number();
		 min.secondminnum(arr);
		 
		 //System.out.println("The second smallest num is:");
		 //System.out.println(secondminnum (arr));
		 
	 }
	

	

			
}


