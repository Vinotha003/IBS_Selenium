package com.Java.Practice.JavaPrograms;

import java.util.Arrays;
public class LongestCommonPrefix {
	public static void prefix(String[] str){
		Arrays.sort(str);
		String first = str[0];
		String sec= str[str.length-1];
		String common =" ";
		int count =0;
		for(int i=0;i<str.length;i++) {
			if(first.charAt(i)==sec.charAt(i)) {
			common +=first.charAt(i);	
			count++;
			}
			else {
				break;
			}
			
		}
		if (count==0)
		{
			System.out.println("There is no Longest common prefix");
		}
		else
		{
			System.out.println("There is  Longest common prefix"+common);	
		}
		
			
	}
	public static void main(String[] args) {
		//String[] str = {"ight","ower","ow"};
		String[] str = {"Flower","Flow","slowur"};
		//String[] str= {"geeksforgeeks","geeks","geek","geezer"};
		prefix(str);
		
	}
}
