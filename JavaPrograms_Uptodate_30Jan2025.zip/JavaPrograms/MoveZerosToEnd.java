package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class MoveZerosToEnd {
	public void ZerosToEnd()
	{
		int[] a= {1,7,0,4,0,6,9,0,3,6};
		int j=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]!=0)
			{
				a[j]=a[i];
				j++;
			}
		}
		for(int i=j;i<a.length;i++)
		{
			a[i]=0;
		}
	System.out.println(Arrays.toString(a));
	}
	
	
	public static void main (String[] args)
	{
		MoveZerosToEnd m=new MoveZerosToEnd();
		m.ZerosToEnd();
	}

}
