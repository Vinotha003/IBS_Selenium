package com.Java.Practice.JavaPrograms;

public class removeSpecialCharacters {
	public void removespclchar()
	{
	String s ="Vinotha03@12$96";
	String v= s.replaceAll("[^a-zA-Z0-9]", "");
	System.out.println(v);
	
	}
	public static void main(String[] args) {
		removeSpecialCharacters rs=new removeSpecialCharacters();
		rs.removespclchar();
	}
	
	
	

}
