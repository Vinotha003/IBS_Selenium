package com.Java.Practice.JavaPrograms;

public class SumOfDigitsInString {
	public static void main(String[] args){
	String str="vi4no6t28ha";
	char[] ch =str.toCharArray();
	int sum = 0;
	for(char c: ch) {
	if(Character.isDigit(c))

	{
		sum +=Character.getNumericValue(c);
	}
	
		}
	System.out.println(sum);
}
}

