package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class RotateArrayToLeft {
	public static void main(String[] args){
		int[] arr= {1,6,99,67,3,57};
		//left rotating string by 3 elements
		
		int rotation=3;
		
		int size = arr.length;
		for(int i=1;i<=rotation;i++) {
		int first = arr[0];
		
		for(int j=0;j<size-1;j++)
		{
			arr[j]=arr[j+1];
		}
		arr[size-1]=first; 
		
		
	}
System.out.println(Arrays.toString(arr));
}
}



