package com.Java.Practice.JavaPrograms;

public class InterviewPractice8 {
	public static void num() {
		int [] arr= {1,2,3,2,4,4,4,5,1};
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==1)
			{
				System.out.println("Integer 1 occurance position :" +(i+1));
			}
		}
	}
	public static void main(String[] args) {
		num();
	}

}
