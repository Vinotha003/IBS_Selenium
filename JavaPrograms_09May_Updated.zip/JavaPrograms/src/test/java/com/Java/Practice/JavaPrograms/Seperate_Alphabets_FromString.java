package com.Java.Practice.JavaPrograms;

public class Seperate_Alphabets_FromString {
	public void seperateAlphabets() {
		String str ="VInotha865@$%";
		//char c[] = str.toCharArray();
		for(char a : str.toCharArray() )
		{
			if (Character.isAlphabetic(a))
			{
			System.out.print(a);
			}
			if (Character.isUpperCase(a))
			{
				System.out.print(a);
			}
		}
		
			
		}
	public void seperateAlphabets_AnotherType() {
		String str ="VInotha865@$%";
		char c[] = str.toCharArray();
		String s= " ";
		for(char a : c )
		{
			if (Character.isAlphabetic(a))
			s +=a;
			
		}
		System.out.println(s);
			
		}
	public static void main(String[] args) {
		Seperate_Alphabets_FromString alph = new Seperate_Alphabets_FromString();
		alph.seperateAlphabets();
		//alph.seperateAlphabets_AnotherType();		
	}
		
	}


