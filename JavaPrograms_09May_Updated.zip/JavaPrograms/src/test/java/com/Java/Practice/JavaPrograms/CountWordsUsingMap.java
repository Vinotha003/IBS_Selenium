package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map;

public class CountWordsUsingMap {// Online Java Compiler
	
	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s="welcome to capgemini to capgemini";
	        String str[]=s.split(" ");
	        Map<String,Integer> hm= new HashMap<>();
	        for(String word:str)
	        {
	        	if(hm.containsKey(word)) {
	           hm.put(word,hm.get(word)+1) ;
	        }
	        	else {
	        		hm.put(word, 1);
	        	}
	        }
	        for(Map.Entry<String,Integer>e:hm.entrySet())
	        {
	            //if(e.getValue()>1)
	           // {
	               System.out.println(e.getKey() +"  " +e.getValue());  
	           // }
	        }
	        
	    }
	}

