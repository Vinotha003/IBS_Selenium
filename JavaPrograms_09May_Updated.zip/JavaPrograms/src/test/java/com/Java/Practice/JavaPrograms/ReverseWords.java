package com.Java.Practice.JavaPrograms;

public class ReverseWords {
	
	    public static void main(String[] args) {
	        
	        String str="welcome to cap";
	        StringBuilder sb=new StringBuilder();
	        String s[]=str.split(" ");
	        
	       for(int i=s.length-1; i>=0;i--){
	        sb.append(s[i]);
	        sb.append(" ");
	    }
	    System.out.println(sb);
	    }
	}


