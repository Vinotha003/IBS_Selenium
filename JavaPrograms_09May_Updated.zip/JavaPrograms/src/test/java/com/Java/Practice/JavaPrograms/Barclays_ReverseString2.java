package com.Java.Practice.JavaPrograms;

public class Barclays_ReverseString2 {
	
		public static void main(String args[])
		{
			
			    
			   String str = "welcome to Barclays";
	        
	        // Split the string by spaces to get each word separately.
	        String[] words = str.split(" ");
	        //System.out.println(words.toString());
	        StringBuilder output = new StringBuilder();

	        // For each word, reverse the characters and add to the output.
	        for (String word : words) {
	            output.append(new StringBuilder(word).reverse().toString()).append(" ");
	        }

	        // Remove the trailing space and print the output.
	        System.out.println("Reverse each word in the string : " + output.toString().trim());
			       
			    }
			}

			   
			





