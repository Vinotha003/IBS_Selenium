package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class RotateArrayToRight {
	public static void main(String[] args){
		int[] arr= {1,6,99,67,3,57};
		//right rotating string by 3 elements
		
		int rotation=3;
		
		int size = arr.length;
		for(int i=1;i<=rotation;i++) {
		int last = arr[size-1];
		
		for(int j=size-1;j>0;j--)
		{
			arr[j]=arr[j-1];
		}
		arr[0]=last; 
		
		
	}
System.out.println(Arrays.toString(arr));
}

}
