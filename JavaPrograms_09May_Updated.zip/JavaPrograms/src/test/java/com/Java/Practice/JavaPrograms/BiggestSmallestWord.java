package com.Java.Practice.JavaPrograms;

public class BiggestSmallestWord {
	  public static void main(String[] args) {
		  
		  String s="Vinotha is good  automation tester";
		  String[] str= s.split(" ");
		  String big=str[0];
		  String small= str[0];
		  for(String word:str)
		  {
			  if(word.length()>big.length())
			  {
				  big=word;
				  
			  }
			  if(word.length()<small.length())
			  {
				  small=word;
			  }
		  }
		  System.out.println(big);
		  System.out.println(small);
	  }
		  

}
