package com.Java.Practice.JavaPrograms;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ReadDataFromExcelUsingMapList {
	public static void main (String[] args) throws IOException {
		//C:\Users\v.rajavel.pandeswari\eclipse-workspace\JavaPrograms\Selenium_excel.xlsx
		File file= new File("C:/Users/v.rajavel.pandeswari/eclipse-workspace/JavaPrograms/Selenium_excel.xlsx");
		FileInputStream ip= new FileInputStream(file);
		XSSFWorkbook wb= new XSSFWorkbook (ip);
		XSSFSheet sh = wb.getSheet("Sheet1");
		List<Map<String,String>> datalist = new ArrayList<>();
		Row headerrow = sh.getRow(0);
		for(int i=1;i<sh.getLastRowNum();i++)
		{
			Row row= sh.getRow(i);
			Map<String,String>datamap=new HashMap<>();
			for(int j=0;j<=row.getLastCellNum();j++)
			{
				String key =headerrow.getCell(j).getStringCellValue();
				String Value =row.getCell(j).getStringCellValue();
				datamap.put(key, Value);
				
		}
			datalist.add(datamap);	
	}
		System.out.println("testdata: "+datalist);
		
	}

}
