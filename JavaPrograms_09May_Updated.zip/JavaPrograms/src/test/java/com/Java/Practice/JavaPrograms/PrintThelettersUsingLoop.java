package com.Java.Practice.JavaPrograms;

public class PrintThelettersUsingLoop {// Online Java Compiler
	// Use this editor to write, compile and run your Java code online

	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s="name";
	        StringBuilder sb=new StringBuilder();
	    
	        for(int i=0;i<s.length();i++)
	        {
	            char ch=s.charAt(i);
	            for(int j=0;j<=i;j++)
	            {
	                sb.append(ch);
	            }
	        }
	        System.out.println(sb);
	    }
	}


