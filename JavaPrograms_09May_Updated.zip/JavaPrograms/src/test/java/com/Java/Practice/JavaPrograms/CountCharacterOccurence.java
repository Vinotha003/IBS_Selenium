package com.Java.Practice.JavaPrograms;

public class CountCharacterOccurence {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Java programming";
		int total=s.length();
		System.out.println("Total length: "+total);
	String r=s.replace("a", "");	
	System.out.println("After replace: "+r);
	System.out.println("After replace length "+r.length());
	int characterOcc=total-r.length();
	System.out.println(characterOcc);
	}

}
