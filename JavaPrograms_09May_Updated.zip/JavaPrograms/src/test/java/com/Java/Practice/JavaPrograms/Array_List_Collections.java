package com.Java.Practice.JavaPrograms;

import java.util.ArrayList;

public class Array_List_Collections {
	// ArrayList is flexible
	public void Interger_Array_List() {
		
				ArrayList<Integer>alist = new ArrayList<Integer>(); // Passing Integer values
			for (int i=0;i<=10;i++)
			{
				alist.add(i);
			}
			System.out.println("Integer ArrayList :" +alist);
				alist.add(100);
				alist.add(200);
				alist.add(300);
				System.out.println("Integer ArrayList :" +alist);
				System.out.println("Getting 4th value from integer ArrayList :" +alist.get(3));
				
		
	}
	public void String_Array_List() {
		ArrayList<String>astring= new ArrayList<String>();
		astring.add("John");
		astring.add("Cat");
		astring.add("Stuart");
		System.out.println("String ArrayList :" +astring);
		astring.set(1, "Sue");
		System.out.println("Modifying the 2nd value in the String ArrayList :" +astring);
	}
	public void Combination_Array_List() {
		ArrayList acomb=new ArrayList();
		acomb.add(200);
		acomb.add(300);
		acomb.add("Cat");
		acomb.add("Stuart");
		System.out.println("Combination ArrayList :" +acomb);
		acomb.remove(2);
		System.out.println("Removing 3rd value from Combination ArrayList :" +acomb);
		System.out.println("Checking the value is present in Combination ArrayList :" +acomb.contains("cat"));
		
	}
	
	public static void main(String args[]) {
		Array_List_Collections al =new Array_List_Collections();
				al.Interger_Array_List();
				al.String_Array_List();
				al.Combination_Array_List();
		
	}

}
