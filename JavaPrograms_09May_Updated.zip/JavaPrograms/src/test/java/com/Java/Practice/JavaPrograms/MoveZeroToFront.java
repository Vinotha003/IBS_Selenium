package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class MoveZeroToFront {
	public static void ZeroToFront()
	{
		int[] a= {1,7,0,4,0,6,9,0,3,6};
		int [] temp=new int[a.length];
		int j=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				temp[j]=a[i];
				j++;
			}
		}
		//System.out.println(j);
		for(int i=0;i<a.length;i++)
		{
			if(a[i]!=0)
			{
				temp[j]=a[i];
				j++;
				
			}
		}
		System.out.println(Arrays.toString(temp));
	//if you want you can copy temp array back to original array that is a[]
		for(int i=0;i<a.length;i++)
		{
			a[i]=temp[i];
			
		}
		System.out.println(Arrays.toString(a));
	}
	public static void main (String[] args)
	{
		
		ZeroToFront();
	}

}


