package com.Java.Practice.JavaPrograms;

public class AddingTwoString {
	public static void main(String[] args){
		String str1="1234";
		String str2 ="5678";
		int result1 = Integer.parseInt(str1)+Integer.parseInt(str2);
		
		System.out.println(result1);
		String s1="10.28";
		String s2="55.56";
		Double result2= Double.parseDouble(s1)+Double.parseDouble(s2);
		System.out.println(result2);
		
		
}

}
