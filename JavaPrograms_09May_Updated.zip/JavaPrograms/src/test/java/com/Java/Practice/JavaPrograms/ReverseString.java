package com.Java.Practice.JavaPrograms;

public class ReverseString {
	 static String reverseUsingForloop() {
		   
		       String original = "hello world";
		       String reversed = "";
		       // Reverse the string using a for loop
		       for (int i = original.length() - 1; i >= 0; i--) {
		           reversed += original.charAt(i); // Append characters in reverse order
		       }
		       System.out.println("Original: " + original);
		       System.out.println("Reversed: " + reversed);
		       return reversed;
		   }
	static String StrBuilder() {
		 String original = "Vinotha";
	       // Use StringBuilder to reverse the string
	       String reversed = new StringBuilder(original).reverse().toString();
	       System.out.println("Original: " + original);
	       System.out.println("Reversed: " + reversed);
		return reversed;
	}
	static String StrBuffer()
	{
		String original = "Sugeertha";
	       // Use StringBuffer to reverse the string
	       StringBuffer stringBuffer = new StringBuffer(original);
	       String reversed = stringBuffer.reverse().toString();
	       System.out.println("Original: " + original);
	       System.out.println("Reversed: " + reversed);
		return reversed;
	}
	public static void main(String[] args) {
		reverseUsingForloop();
		StrBuilder();
		StrBuffer();
		
		
	}
		}

