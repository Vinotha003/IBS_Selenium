package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map.Entry;

public class InteviewPractice5 {
	public static void CountInt(int arr[]) {
		HashMap<Integer,Integer>hm=new HashMap<>();
		for(int i : arr)
		{
			if(hm.containsKey(i))
			{
				hm.put(i, hm.get(i)+1);
				
			}
			else
			{
				hm.put(i, 1);
			}
		}
		for(Entry<Integer,Integer>e:hm.entrySet())
		{
			//if(e.getValue()>1) {
			System.out.println(e.getKey() +": " +e.getValue());
		}
			
		
		
		}
		
		
		
	
	 public static void main(String[] args){
		 int arr[]= {1,2,2,4,7,8,5,4,6,5,4};
		 //int arr[]= {1,2,7,8,6,5};
		 CountInt(arr);
		 
	 }

}
