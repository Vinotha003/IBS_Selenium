package com.Java.Practice.JavaPrograms;

public class BarclaysInterview_3 {
	public static void main(String args[])
	{
		String s ="vino";
		String First =" ";
		if(s.length()>1) {
		//String First = s.substring(0,1);
			 First+= s.charAt(0);
		String remaining = s.substring(1);
		String reverse = new StringBuilder(remaining).reverse().toString();
		reverse = First+reverse;
		System.out.println(reverse);
		
		
	}
		else {
			System.out.println("The word length is not greater than 1" );
		}
	}
	

}
