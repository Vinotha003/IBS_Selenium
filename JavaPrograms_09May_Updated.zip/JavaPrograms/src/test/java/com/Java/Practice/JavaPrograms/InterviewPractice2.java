package com.Java.Practice.JavaPrograms;

import javax.xml.stream.events.Characters;

public class InterviewPractice2 {
	String s="VInotHA@#$45678";
	public  void practice2() {
		char ch[]= s.toCharArray();
		System.out.println("uppercases are");
		for(char c:ch)
		{
			
			if (Character.isUpperCase(c))
			{
				System.out.println(c);
			}
			
			/*if(Character.isDigit(c))
			{
				System.out.println(c);
			}
			if (Character.isAlphabetic(c))
			{
				System.out.println(c);
			}*/
		}
		
	}
	
		
	public static void main(String args[])
	{
		InterviewPractice2 ip2 = new InterviewPractice2();
		ip2.practice2();
		
	}
}
