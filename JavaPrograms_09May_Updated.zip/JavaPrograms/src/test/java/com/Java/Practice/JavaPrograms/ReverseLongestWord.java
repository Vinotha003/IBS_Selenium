package com.Java.Practice.JavaPrograms;

public class ReverseLongestWord {
	public static void main(String args[])
	{
		String str="Vinotha is good at automation";
		
		String [] s=str.split(" ");
		int maxlength=0;
		String longestword=" ";
		for(String word: s)
		{
			if(word.length()>maxlength)
			{
				maxlength= word.length();
				longestword=word;
				System.out.println(longestword);	
			}
		}
		String rev= new StringBuilder(longestword).reverse().toString();
		String res= str.replaceFirst(longestword, rev);// replace the longest word with reverse in the str
		System.out.println(res);
	}
	
	

}
