package com.Java.Practice.JavaPrograms;

public class SwapNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Addition operator");
		int a=10;
		int b=20;
		System.out.println("Before Swapping "+a +" "+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After swapping "+a +" "+b);


		System.out.println("Mul-Div operator");
		a=20;
		b=30;
		System.out.println("Before Swapping "+a +" "+b);
		a=a*b;
		b=a/b;
		a=a/b;
		System.out.println("After swapping "+a +" "+b);

		
		//Using third variable

		System.out.println("Using third variable");
		a=40;
		b=50;
		int temp=0;

		System.out.println("Before Swapping "+a +" "+b);

		temp=a;
		a=b;
		b=temp;

		System.out.println("After swapping "+a +" "+b);











	}

}
