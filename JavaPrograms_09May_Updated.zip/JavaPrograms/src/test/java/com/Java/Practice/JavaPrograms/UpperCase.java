package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class UpperCase {
	public void Up() {
	String[] s = {"hello","HEllo","HeLlo"};
	
	System.out.println(s.length);
	for (int i=0 ; i<s.length;i++) {
		
		s[i] =s[i].toUpperCase();
	
	}
	System.out.print(Arrays.toString(s));
	}
	public static void main(String[] args) {
		UpperCase uc =new UpperCase();
		uc.Up();
	}

}
