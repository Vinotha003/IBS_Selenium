package com.Java.Practice.JavaPrograms;

public class ReverseLastThreeLetters {
	public static void main(String[] args) {
	String str="shithal";
	StringBuilder sb= new StringBuilder();
	if(str.length()<=3) {
		String rev = new StringBuilder(str).reverse().toString();
		System.out.println(rev);
		
						}
	else {
		String firstpart=str.substring(0,str.length()-3);
		String secondpart = new StringBuilder(str.substring(3)).reverse().toString();
		String revlastthree=firstpart + secondpart;
		System.out.println(revlastthree);
		}	
	
	}
}
