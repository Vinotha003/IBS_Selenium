package com.Java.Practice.JavaPrograms;

public class SampleStringOccurrance {
	
	public void StringOccurance(String str) {
		 int Max_char= 256;
	
	int count[]=new int[Max_char];
	for(int i =0; i<str.length();i++) {
		count[str.charAt(i)]++;
		/*System.out.println("Number  "
				+str.charAt(i)+ " is " +count[str.charAt(i)]);	*/
	}
	char ch[]=new char[str.length()];
	for (int i =0;i<str.length();i++) {
		ch[i]=str.charAt(i);
		int find =0;
		for(int j=0;j<=i;j++) {
			if(str.charAt(i)==ch[j]) {
				find++;
			
			}
		}
			if (find==1) {
				System.out.println("Number of occurance of "
			+str.charAt(i)+ " is " +count[str.charAt(i)]);
			}
		
		
	}
	}
	public static void main(String[] args)
    {
		SampleStringOccurrance so =new SampleStringOccurrance();
		String str = "geeksforgeeks";
		so.StringOccurance(str);
    }

}
