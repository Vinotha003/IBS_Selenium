package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map.Entry;

public class Hashmap_Sample2 {
	public static void map(String s)
	{	
HashMap<Character,Integer>hm =new HashMap<>();
char[] ch=s.toCharArray();
for(char c : ch)
{
	if(hm.containsKey(c))
	{
		hm.put(c, hm.get(c)+ 1);
		
	}
	else
	{
		hm.put(c, 1);

}
}
//System.out.println(hm);
for (Entry<Character, Integer> e : hm.entrySet())
{
	System.out.println(e.getKey() +":" + e.getValue());
}

}
	public static void main(String[] args){
		 String s ="Sugeeertha";
		map(s);
	    }
}

