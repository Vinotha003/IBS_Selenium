package com.Java.Practice.JavaPrograms;

public class RotateStringToLeft {
	public static void main(String[] args){
		String str="vinotha";
		//left rotating string by 3 elements
		//vinotha = othavin
		int rotation=3;
		char[] c1 =str.toCharArray();
		int size = c1.length;
		for(int i=1;i<=rotation;i++) {
		char first = c1[0];// v for 1st loop;i for 2nd loop;n for 3rd loop
		
		for(int j=0;j<size-1;j++)
		{
			c1[j]=c1[j+1];//c[0] =c[0+1] ie) v=i;i=n,n=o,o=t;t=h;h=a for i= 1st loop =inotha
							//for i=2nd loop inothav bcomes  i=n;n=o;o=t;t=h;h=a;a=v--->nothav
							//for i= 3rd loop nothavi bcomes n=0;o=t;t=h;h=a;a=v;v=i--->othavi
			
		}
		c1[size-1]=first; //--->inothav for 1st loop 
								//nothavi for 2nd loop
								//othavin for 3rd loop
		
		
	}
System.out.println(c1);
}
}

//OUTPUT
//vinotha == *o*t*h*a*v*i*n --->rotating left by 3 element
//vinotha == *t*h*a*v*i*n*o --->rotating left by 4 element
