package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


public class IntergerOccuranceUsingHashMap {
	public static void IntergerOccurance(int array[]) {
		Map<Integer,Integer> hm = new HashMap<>();
		//HashMap<Integer,Integer> hm = new HashMap<>();
		for(int i : array) {
			if(hm.containsKey(i)) {
				hm.put(i, hm.get(i)+1);
			}
			else {
				hm.put(i, 1);
			}
			//System.out.println(hm);
		}
		for (Entry<Integer,Integer>e:hm.entrySet())
		{
			System.out.println(e.getKey() + ": " + e.getValue());
		}
			

}
	 public static void main(String[] args){
		 int array[] = {1,2,3,3,4,4,4,5};
		 IntergerOccurance(array);
		 
		
	    }
}
