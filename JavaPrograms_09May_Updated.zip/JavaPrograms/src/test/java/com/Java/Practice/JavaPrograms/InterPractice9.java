package com.Java.Practice.JavaPrograms;

public class InterPractice9 {
	public static void sam() {
		String str="Vinotha";
		String rev=" ";
		for(int i=str.length()-1;i>=0;i--) {
			 rev+=str.charAt(i);
			//System.out.println(rev);
		}
		System.out.println(rev);
	}
	public static void pangram() {
		String str="abcdefghijklmnopqrstuvwxyz12345";
		Boolean allchar=true;
		for(char c='a';c<='z';c++) {
			if(!str.contains(String.valueOf(c)))
			{
				 allchar=false;
				 break;
			}
		}
		if(allchar) {
			System.out.println("The given string is panagram");
		}
		else {
			System.out.println("The given string is not panagram");
		}
		
	}
	 public static void main(String args[])
	    {
		 sam();
		 pangram();
	    }

}
