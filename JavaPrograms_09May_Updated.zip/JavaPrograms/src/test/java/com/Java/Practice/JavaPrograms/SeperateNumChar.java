package com.Java.Practice.JavaPrograms;

public class SeperateNumChar {
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s="arv03121996vin";
	        StringBuilder sb1=new StringBuilder();
	         StringBuilder sb2=new StringBuilder();
	        for(char ch:s.toCharArray())
	        {
	            if(Character.isLetter(ch))
	            {
	                sb1.append(ch);
	                
	            }
	            if(Character.isDigit(ch))
	            {
	                sb2.append(ch);
	            }
	        }
	        System.out.println(sb1);
	         System.out.println(sb2);
	    }
	}


