package com.Java.Practice.JavaPrograms;

public class MaxMin {

		public static void Max(int a[]){
			int max=a[0];
			for(int i=1;i<=a.length-1;i++) {
			if(max<a[i]) {
			max=a[i];	
			}
			
		}
			System.out.println("Max Num : " +max);
		}
		
		public static void Min(int a[]){
			int min=a[0];
			for(int i=1;i<=a.length-1;i++) {
			if(min>a[i]) {
			min=a[i];	
			}
			
		}
			System.out.println("Min Num : " +min);
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub

			int a[]= {20,50,60,90,30,10};
			
			Max(a);
			
			Min(a);
			
		}

	}


