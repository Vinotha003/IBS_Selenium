package com.Java.Practice.JavaPrograms;

public class RotateStringToRight {
	public static void main(String[] args){
		String str="vinotha";
		//right rotating string by 3 elements
		//vinotha = thavino
		int rotation=3;
		char[] c1 =str.toCharArray();
		int size = c1.length;
		for(int i=1;i<=rotation;i++) {
		char last = c1[size-1];// a for 1st loop;h for 2nd loop;t for 3rd loop
		
		for(int j=size-1;j>0;j--)
		{
			c1[j]=c1[j-1];	
			//c[6] =c[5] ie) vinothh 
			//c[5] =c[4] ie) vinotth; and so on...vinooth,vinnoth;viinoth;vvinoth for i=1st loop
						//avinoth--->avinott;avinoot;avinnot;aviinot;avvinot;aavinot for i=2nd loop
						//havinot--->havinoo;havinno;haviino;havvino;haavino;hhavino for i=3rd loop
		}
		c1[0]=last; //--->avinoth for i =1st loop 
					//--->havinot for i=2nd loop
					//--->thavino for i=3rd loop 
		
		}
		System.out.println(c1);
		/*//If you want to convert char array to String
		StringBuilder sb = new StringBuilder();
		for(char ch : c1)
		{
			sb.append(ch);
		}
		System.out.println(sb);*/
}
}

//OUTPUT
//vinotha == *t*h*a*v*i*n*o --->rotating right by 3 element
//vinotha == *o*t*h*a*v*i*n --->rotating right by 4 element



