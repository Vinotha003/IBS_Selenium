package com.Java.Practice.JavaPrograms;

public class InterviewPractice6 {
	public static void reverse() {
		String str="Welcome";
		StringBuffer sb = new StringBuffer(str);
		sb.reverse().toString();
		System.out.println(sb);
				
	}
	public static void reverse1() {
		String str="Welcome";
		int n = str.length()/2;
		String first = str.substring(0,n);
		String second = str.substring(n);
		String result = first+ " "+second;
		System.out.println(result);
		
				
	}
	public static void SpaceUsingStringBuffer() {
		String str="WelcometoBarclays";
		StringBuffer sb = new StringBuffer();
		/*int n = str.length()/2;
		sb.insert(n, " ");
		System.out.println(sb);*/
		String first = str.substring(0,7);
		String sec = str.substring(7,9);
		String third = str.substring(9);
		//sb.append(first).append(" ").append(sec).append(" ").append(third).append(" ");
		sb.append(str.substring(0,7)).append(" ").append(str.substring(7,9));
		System.out.println(sb);
		
		
		
		
		
	}
	public static void main (String args[]) {
		//SpaceUsingStringBuffer();
		reverse1();
		
	}

}
