package com.Java.Practice.JavaPrograms;

public class Second_Maximum_Number {
	public static int secondmaxnum (int arr[])
	{
		//5,78,89,3,2
	int first= Integer.MIN_VALUE;
	int secondmax = Integer.MIN_VALUE;
	for (int i=0; i<arr.length; i++)
	{
	if (arr[i]>first) //
	{
		secondmax=first;
		first=arr[i];
		
		
	}
	else if (arr[i]> secondmax && arr[i]!= first )
	{
		secondmax =arr[i];
		
	}
	
	}
	return secondmax;
	
	}
	 public static void main(String[] args) {
		 int arr[] = {1,-99,4,32,32,38,2};
		 System.out.println("The second largest num is:");
		 System.out.println(secondmaxnum (arr));
	 }
	

	

			
}
