package com.Java.Practice.JavaPrograms;

import java.util.ArrayList;
import java.util.List;

public class SeperateNumStringFromArray {// Online Java Compiler
	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        String s[]={"Apple","Banana","1234","356","pom"};
	    List<Integer> num=new ArrayList<>();
	     List<String> name=new ArrayList<>();
	     //StringBuilder sb=new StringBuilder<>();
	     for(String item:s)
	     {
	         //String trimmed= item.trim();
	         if (item.matches("\\d+"))
	         {
	             num.add(Integer.parseInt(item));
	             
	         }
	         else
	         {
	            name.add(item); 
	         }
	         
	     }
	     System.out.println(num);
	      System.out.println(name);
	    }
	}


