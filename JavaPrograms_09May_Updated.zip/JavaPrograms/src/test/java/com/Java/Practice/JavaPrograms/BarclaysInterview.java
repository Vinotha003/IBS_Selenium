package com.Java.Practice.JavaPrograms;

public class BarclaysInterview {
	public static void main(String args[])
	{
		
		      /*  String str = "welcome to Barclays";
		        
		        // Split the string by spaces to get each word separately.
		        String[] words = str.split(" ");
		        //System.out.println(words.toString());
		        StringBuilder output = new StringBuilder();

		        // For each word, reverse the characters and add to the output.
		        for (String word : words) {
		            output.append(new StringBuilder(word).reverse().toString()).append(" ");
		        }

		        // Remove the trailing space and print the output.
		        System.out.println(output.toString().trim());*/
		
		
		        String str = "welcome to Barclays";
		        
		        // Split the string into individual words
		        String[] words = str.split(" ");
		        StringBuilder output = new StringBuilder();

		        for (String word : words) {
		            // Check if the word length is greater than 1
		            if (word.length() > 1) {
		                // Append the first character
		                output.append(word.charAt(0));
		            	//output.append(word.substring(0,1));
		                System.out.println("Append 1st letter:" + output);
		                
		                // Reverse the remaining characters and append to output
		                String reversedPart = new StringBuilder(word.substring(1)).reverse().toString();
		                System.out.println("Reversed part :" + reversedPart.toString());
		                output.append(reversedPart);
		            } else {
		                // If the word length is 1 (e.g., "to"), append it directly
		                output.append(word);
		            }
		            
		            // Add space after each word
		            output.append(" ");
		        }

		        // Remove the trailing space and print the output
		        System.out.println("Final output : " + output.toString().trim());
		    }
		}

		   
		


