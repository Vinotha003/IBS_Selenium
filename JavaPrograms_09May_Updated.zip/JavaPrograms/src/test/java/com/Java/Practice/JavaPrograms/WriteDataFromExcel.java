package com.Java.Practice.JavaPrograms;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class WriteDataFromExcel {
	   public static void main(String[] args) throws IOException {
		File file=new File("C:/Users/v.rajavel.pandeswari/eclipse-workspace/JavaPrograms/Selenium_excel.xlsx");
		
		XSSFWorkbook wb= new XSSFWorkbook();
		XSSFSheet sh =wb.createSheet("Result");
		XSSFRow headerrow= sh.createRow(0);
		headerrow.createCell(0).setCellValue("TC ID");
		headerrow.createCell(1).setCellValue("TC Name");
		headerrow.createCell(1).setCellValue("TC Result");
		XSSFRow row = sh.createRow(1);
		
		row.createCell(0).setCellValue("TC001");
		row.createCell(1).setCellValue("Login");
		row.createCell(1).setCellValue("Pass");
		 
		FileOutputStream op= new FileOutputStream(file);
		wb.close();
		op.close();
		 System.out.println("Data written successfully.");

}
}
