package com.Java.Practice.JavaPrograms;

import java.util.Arrays;
import java.util.Collections;

public class SortNumbers {
public void SortNumbers_Ascending() {
	int a[]= {3,3,99,6,767,0,89,1};
	int num = a.length;
	Arrays.sort(a);
	System.out.println("Sorted array in Ascending order: " + Arrays.toString(a));
	System.out.println("Second largest number: " +  a[num-2]);
	System.out.println("Second smallest number: " +  a[1]);

	
}
public void SortNumbers_Descending() {
	Integer b[]= {3,3,99,6,767,0,89,1};
	 //Collections.reverseOrder();
	 Arrays.sort(b, Collections.reverseOrder());
	 
	System.out.println("Sorted array in descending order: " + Arrays.toString(b));	
	
}

public static void main(String[] args) {
	
	SortNumbers sn= new SortNumbers();
	sn.SortNumbers_Ascending();
	sn.SortNumbers_Descending();
}
}
