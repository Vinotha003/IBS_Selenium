package com.Java.Practice.JavaPrograms;

public class Second_HighestAndSmallest {
	
	    public static void main(String[] args) {
	        System.out.println("Try programiz.pro");
	        int[] a={18,8,55,4,6,3,2,7,10};
	        int temp;
	        for(int i=0;i<a.length;i++)
	        {
	            for(int j=i+1;j<a.length;j++)
	            {
	                if(a[i] > a[j])
	                {
	                    temp=a[i];
	                    a[i]=a[j];
	                    a[j]=temp;
	                  
	                    
	                }
	                
	            }
	        }
	         //System.out.println(Arrays.toString(a));
	         System.out.println("Second Highest : " +a[a.length-2]);
	         System.out.println("Second Smallest : " +a[1]);
	         
	    }
	}


