package com.Java.Practice.JavaPrograms;

import java.util.HashSet;

public class LongestSubstring {
	
	    public static void lengthOfLongestSubstring(String s) {
	        HashSet<Character> set = new HashSet<>();
	       String LongestSubstringTillNow =" ";
	       String LongestSubstringOverall="";
	       
	       for( int i=0;i<s.length();i++){
	    	   char ch =s.charAt(i);
	    	   if(set.contains(ch))
	    	   {
	    		   LongestSubstringTillNow=" ";
	    		   set.clear();
	    		   
	       }
	    	   LongestSubstringTillNow +=ch;
	    	   set.add(ch);
	    	 if(LongestSubstringTillNow.length()>LongestSubstringOverall.length())
	    	 {
	    		 LongestSubstringOverall=LongestSubstringTillNow;
	    		 //System.out.println(LongestSubstringOverall);
	    	 }
	    	   
	       }    
	       System.out.println(LongestSubstringOverall);
	    }
	    public static void main(String[] args) {
	    String s="asbtebnkgt";
	    lengthOfLongestSubstring(s);
	    
	    }
	    
	    }

