package com.Java.Practice.JavaPrograms;

public class ForEach_Loop {
	int[] a= {1,88,3256,89,2}; //array is fixed size
	
	public void ForLoop(){
		System.out.println("Using For loop");
	for(int i= 0;i<=a.length;i++)
	{
		System.out.println(a[i]);
	}
	}
	public void ForEachLoop() {
		System.out.println("Using For Each loop");
		for(int var : a)
		{
			System.out.println(var);	
	
		}
	}
		
	
	public static void main(String[] args) {
		ForEach_Loop fp = new ForEach_Loop();
		//fp.ForLoop();
		fp.ForEachLoop();
	}
	
		

}
