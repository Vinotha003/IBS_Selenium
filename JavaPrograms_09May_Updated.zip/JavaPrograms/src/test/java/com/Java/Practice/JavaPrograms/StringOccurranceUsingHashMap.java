package com.Java.Practice.JavaPrograms;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class StringOccurranceUsingHashMap {
   
public static void countCharacterOccurrences(String str) {
	        // Create a HashMap to store character occurrences
	        Map<Character, Integer> characterCountMap = new HashMap<>();
	      //HashMap<Character,Integer> hm = new HashMap<>();
	        // Convert the string to a character array
	        char[] characters = str.toCharArray();
	        
	        // Iterate over each character in the array
	        for (char c : characters) {
	            // If the character is already in the map, increment its count
	            if (characterCountMap.containsKey(c)) {
	                characterCountMap.put(c, characterCountMap.get(c) + 1);
	            } else {
	                // Otherwise, add the character to the map with count 1
	                characterCountMap.put(c, 1);
	            }
	        }
	        for (Entry<Character, Integer> entry :characterCountMap.entrySet()) {
				//if(entry.getValue()>1) {
	        	System.out.println(entry.getKey()+":"+entry.getValue());
			}
	       // }
	        // Return the map with character counts
	      //  return characterCountMap;
	    }
public static void main(String[] args) {
	String str = "Sugeertha";
	countCharacterOccurrences(str);
	
	
}
	}



