package com.Java.Practice.JavaPrograms;

import java.util.Arrays;

public class InterviewPractice1 {
	public static  void practic1()
	{
		String s="Vinoitha";
		int count =0;
		char ch[] = s.toCharArray();
		//System.out.println(ch);
		for (int i=0;i<ch.length;i++)
		{
		if (ch[i]== 'a' || ch[i]== 'e' ||ch[i]== 'i' ||ch[i]== 'o' || ch[i]== 'u')
		{
		 count++;
		 System .out.println("vowels are : " +ch[i] +" is " +count);
		 
		}
			
	}
		//return count;
		//System .out.print(count);
	}
	public static void main (String[] args)
	{
		InterviewPractice1 ip1 = new InterviewPractice1();
		ip1.practic1();
		//practic1();
	}


}
