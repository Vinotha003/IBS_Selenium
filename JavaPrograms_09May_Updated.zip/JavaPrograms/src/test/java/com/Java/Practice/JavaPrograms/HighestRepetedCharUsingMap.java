package com.Java.Practice.JavaPrograms;

import java.util.HashMap;
import java.util.Map;

public class HighestRepetedCharUsingMap {


	    public static void main(String[] args) {
	      //  System.out.println("Try programiz.pro");
	        String str="MoNsoon";
	        str.toLowerCase();
	        int maxcount=0;
		    char maxchar=' ';
	    Map<Character,Integer> hm= new HashMap<>();
	    char c[] = str.toCharArray();
	    for(Character ch:c)
	    {
	      if(hm.containsKey(ch))
	      {
	      hm.put(ch,hm.get(ch)+1);  
	    }
	    else
	    {
	        hm.put(ch,1);
	    }
	    
	    }
	     
	   for(Map.Entry<Character,Integer> e:hm.entrySet()){
	      
	        if(e.getValue()>maxcount)
	        {
	            maxcount=e.getValue();
	            maxchar=e.getKey();
	        }
	    
	        
	    }
	    System.out.println(maxchar +" - " + maxcount);
	   //System.out.println(hm);
	    }
	}

